import library;
public class Book{
    public Book() {
        String bookName = "Harry Potter";
    }

    public void rrrrar() {
        int a = 3;
        if (a > 3) {
            int c = 5;
        }
        double d = 3.4;
        while (d < b) {
            int e = 1;
        }
        for (int i=0; i<6; i++) {
            int f = 4;
        }
    }
}