import library
class Book:
	def __init__(self):
		bookName = "Harry Potter"
	def rrrrar(self):
		a = 3
		if a>3:
			c = 5
		d = 3.4
		while d<b:
			e = 1
		for x in range(0, 6, -1):
			i = 0
			f = 4
